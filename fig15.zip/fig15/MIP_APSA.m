function out = MIP_APSA(Input,Output,Oweight,weight,rate,alpha,Tap,K,HL)
L = length(Input);
for n = Tap+K+1:L
    Input_temp = [Input(n:-1:n-Tap+1)];
    for k = 2:K
        Input_temp = [Input_temp Input(n-k+1:-1:n-Tap-k+2)];
    end
    Output_tmep = Output(n:-1:n-K+1);
    if n == Tap+K+1
        P  = Input_temp;
    end
    if n<= HL
        Oweight_temp = Oweight(:,1);
    else
        Oweight_temp = Oweight(:,2);
        if n == HL+1
            weight = zeros(Tap,1);
        end
    end
    OU = MIP_APSA_code(Input_temp,Output_tmep,weight,rate,alpha,P,Tap,K);
    weight =  OU.weight;
    P      =  OU.P;
    out.MisWe(n) = 10*log10(norm(weight - Oweight_temp)./(norm(Oweight_temp))); % the normalized misalignment
end
out.final_weight = weight;
end