function out = MIP_APSA_code(input,output,weight,rate,alpha,P,Tap,K)
    err = output - input'*weight;
    gm   = (1-alpha)/(2*Tap).*ones(Tap,1) + (1+alpha).*abs(weight)/(2*norm(weight,1) + 0.01);
    P    = [gm.*input(:,1) P(:,1:K-1)];
    input_s = P*sign(err);
    weight  = weight + rate*input_s./(sqrt( norm(input_s)^2 + 0.05   ));
    out.weight = weight;
    out.P      = P;
end