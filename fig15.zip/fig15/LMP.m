function out = LMP(Input,Output,Oweight,weight,rate,Tap,K,L,p)
%L = length(Input);
for n = Tap+K+1:L
    Input_temp = [Input(n:-1:n-Tap+1)];
   
        Input_temp = [Input_temp ];
  
    Output_tmep = Output(n:-1:n-K+1);
  
        Oweight_temp = Oweight(:,1);
 
    OU = LMP_code(Input_temp,Output_tmep,weight,rate,Tap,p);
    weight =  OU.weight;
    
    out.MisWe(n) = 10*log10(norm(weight - Oweight_temp)); % the normalized misalignment
end
out.final_weight = weight;
end