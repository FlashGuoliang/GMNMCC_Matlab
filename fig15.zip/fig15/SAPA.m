function out = SAPA(Input,Output,Oweight,weight,rate,epsilon,Tap,K,L,a_sapa,b_sapa)
%L = length(Input);                          %��ʾ�����źŵĳ���
for n = Tap+K+1:L
    Input_temp = [Input(n:-1:n-Tap+1)];     %��ʾ�����е�Un
    for k = 2:K
        Input_temp = [Input_temp Input(n-k+1:-1:n-Tap-k+2)];
    end
    Output_tmep = Output(n:-1:n-K+1);
    %if n<= HL
        Oweight_temp = Oweight(:,1);
  %  else
    %    Oweight_temp = Oweight(:,2);
    %    if n == HL+1
   %         weight = zeros(Tap,1);
   %     end
  %  end
    
    OU = SAPA_code(Input_temp,Output_tmep,weight,rate,epsilon,a_sapa,b_sapa);
    weight =  OU.weight;
    out.MisWe(n) = 10*log10(norm(weight - Oweight_temp)); % the normalized misalignment
end
out.final_weight = weight;
end