function out = APGMCC_code(input,output,weight,rate,epsilon,r,K,alpha)
    err = output - input'*weight;
    B=zeros(1,K);
    for k=1:K
        B(k)=exp(-1*r*abs(err(k))^alpha)*(abs(err(k)))^(alpha-1);
    end
    B=diag(B);
   input_s = input*sign(err);
    weight=weight+rate*input*B*sign(err)./(sqrt( norm(input*B*sign(err))^2+ epsilon  )); 
  
    out.weight = weight;
end