function out = APGMNMCC(Input,Output,Oweight,weight,rate,epsilon,Tap,K,HL,a1,a2,a,b,ERR,TT,BG)
L = length(Input);                          %��ʾ�����źŵĳ���
S1=zeros(L,1);
S2=zeros(L,1);
ERR1=zeros(K,1);
s1=zeros(K,1);
s2=zeros(K,1);
v=zeros(K,1);
for n = Tap+K+1:L
    Input_temp = [Input(n:-1:n-Tap+1)];     %��ʾ�����е�Un
    for k = 2:K
        Input_temp = [Input_temp Input(n-k+1:-1:n-Tap-k+2)];
    end
    Output_tmep = Output(n:-1:n-K+1);
    if n<= HL
        Oweight_temp = Oweight(:,1);
    else
       Oweight_temp = Oweight(:,2);
      %  if n == HL+1
        %    weight = zeros(Tap,1);
        %end
    end
    
    OU = APGMNMCC_code(Input_temp,Output_tmep,weight,rate,epsilon,a1,a2,a,b,n,ERR1,K,s1,s2,v,BG);
    weight =  OU.weight;
    
    
   ERR(n:-1:n-K+1)=OU.ERR1-BG(n:-1:n-K+1);
   S1(n:-1:n-K+1)=OU.s1;
    S2(n:-1:n-K+1)=OU.s2;
  
   S=0;
   SS1=0;
   SS2=0;
   
   for i=(n-TT+1):n
       if i<=0
           S=0;
             SS1=0;
             SS2=0;
       else
      S= [S+ERR(i)^2];
        SS1= [SS1+S1(i)];
          SS2= [SS2+S2(i)];
       end
   end
        out.MisER(n)=(S);
           out.MisERS1(n)=(SS1);
           out.MisERS2(n)=(SS2);
            out.MisWe(n) = 10*log10(norm(weight - Oweight_temp)); % the normalized misalignment
end
out.final_weight = weight;
out.final_ERR = ERR;
end