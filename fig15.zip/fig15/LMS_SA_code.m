function out = LMS_SA_code(input,output,weight,rate,Tap,a)
    err = output - input'*weight; 
   input_s=sign(err(1))*input;
    weight  = weight + rate*[input_s*a+2*(1-a)*err(1)*input];
    out.weight = weight;
  
end