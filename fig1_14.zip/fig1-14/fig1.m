clear all
close all
clc
%%%%%%%%%% parameter setting $$$$$$$$$$
a=2;
b=1;
e1=1;
e2=1;
gap=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%
[x1 x2] = meshgrid(-2:gap:2,-2:gap:2);
a1=a/(2*b*gamma(1/a));
xc1=e1*abs(x1)+e2*(x1).^2;
xc2=e1*abs(x2)+e2*(x2).^2;
J=a1-0.5*a1*[exp(-xc1.^2) +  exp(-xc2.^2)];
J=J.^(0.5);

%%%%%%%%% plot  %%%%%%%%%%
surf(x1,x2,J);
hold on
contour(x1,x2,J);
%J=contour(x1,x2,J);
xlabel('x_{1}');
ylabel('x_{2}');
%title('Surface of the GMNCIM');
