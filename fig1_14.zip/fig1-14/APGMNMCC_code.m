function out = APGMNMCC_code(input,output,weight,rate,epsilon,a1,a2,a,b,n, ERR1,K, s1, s2,v,BG)

    err = output - input'*weight;
    input_s = input*sign(err);

    weight  = weight + rate.*input*([exp(-b.*(a1.*abs( err)+a2.*err.^2).^a)].*[( a1.*abs( err)+a2.* err.^2 ).^(a-1)].*[(a1.*sign(err)+2.*a2.*err )]);
 
     ERR1=err;
     
     %%%%%%%%%%%%%%%%% theory excess MSE (EMSE)%%%%%%%%%%%
     v=BG(n:-1:n-K+1);
     s1=[exp(-2.*b.*(a1.*abs(v)+a2.*v.^2).^a)].*[( a1.*abs(v)+a2.*v.^2 ).^(2*a-2)].*[(a1.*sign(v)+2.*a2.*v ).^2];
     s2=[exp(-2.*b.*(a1.*abs(v)+a2.*v.^2).^a)].*[( a1.*abs(v)+a2.*v.^2 ).^(2.*a-2)].*[(a1.*sign(v)+2.*a2.*v ).^2].*(-b.*a)+[exp(-2.*b.*(a1.*abs(v)+a2.*v.^2).^a)].*[( a1.*abs(v)+a2.*v.^2 ).^(a-2)].*[(a1.*sign(v)+2.*a2.*v ).^2].*(a-1)+[exp(-2.*b.*(a1.*abs(v)+a2.*v.^2).^a)].*[( a1.*abs(v)+a2.*v.^2 ).^(a-1)].*[(a1.*dirac(v)+2.*a2.*ones(K,1) )];
     
     
     
     
     
    %%%%%%%%%%%%%%%%%%%%%%% 
    out.ERR1=ERR1;
      out.s1=s1;
      out.s2=s2;
    out.weight = weight;
end