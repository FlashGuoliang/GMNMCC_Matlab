close all;
clc;
 load acousticpath
    h1=38*a_ir(1:(512));
    h2=0.5*38*a_ir(391:512);
    h3=0.3*38*a_ir(391:512);
    h4=0.1*38*a_ir(391:512);
    h5=0.05*38*a_ir(391:512);
    h6=0.01*38*a_ir(489:512);
    h7=[h1' h2' h3' h4' h5' h6'];
    w_opt=1*h7';
    figure
    plot(    w_opt, 'b', 'LineWidth', 1);
    hold on
    xlabel('Impulse response of acoustic-echo-path with {\it M} = 1024.');
ylabel('Amplitude');