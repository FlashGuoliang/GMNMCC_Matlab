clear all
close all
clc
t1 = cputime;
N   =100;
TT=10;
Tap = 10;  
%K   = 1;
Length = 5000;
HL=5000;
%%%%%%%%%%%%% APRMNA
mu_SA=0.001;  mu_LMS=0.002; mu_RMNA=0.001;  mu_GMCC=0.002; 
mu_APA=0.0005;  mu_APLMCC=0.0005;  mu_GMNMCC=0.001;  mu_APGMNMCC=0.0002; 
mu_SAPA=0.12,a_sapa=1;b_sapa=0.01;
mu_SSM_AAPGMC=0.012,a_SSM_AAPGMC=1;b_SSM_AAPGMC=0.01;ax=0.4;
%rate=0.001;
%MU=[ 1 5];              
K=5;
%MU=0.01;

RMNA_a=0.12;
a1=1;               % the first mixed factor
a2=1;               % the second mixed factor
a=2;             % shape factor
b=0.001;          %  kernel factor
%% Input - Output pairs
Input_white_sequence  =  randn(Length,1);
Input_color_sequence  = Input_white_sequence;
%Input_color_sequence  =  filter(1,[1 -0.7],Input_white_sequence);
%Input_color_sequence  =  filter([1 0.6],[1 1 0.21],Input_white_sequence);
Oweight1               =  zeros(Tap,1);
for n = 1 : round(Tap)                 %%  ����1*Tap�������
    Oweight1(unidrnd(Tap)) = randn;
end
%Oweight1               =  [0.11 0.21 0.31 0.41 0.51 0.51 0.41 0.31 0.21 0.11]';
Oweight2               = -Oweight1;
Oweight                = [Oweight1 Oweight2];

Output_temp1           =  filter(Oweight1,1,Input_color_sequence(1:HL));
Output_temp2           =  filter(Oweight2,1,Input_color_sequence((HL+1):end));
Output_temp            =  [Output_temp1 ; Output_temp2];
ERR=zeros(Length,1);
A=zeros(Length,1)';
%SE=zeros(Length,1);
%% runs

   % fno(m)=4*no^2/12;
for n = 1:N
    if ~mod(n,N/10), fprintf('.'); end               %%       �ж��Ƿ�20/10����
    weight = zeros(Tap,1);
    Output_white =Output_temp;
   %  Output_white = AWGNgen(Output_temp,30);
  %  Output_white = awgn(Output_temp,30,'measured');   %%����ɫ��˹�������ӵ��ź���
%     10*log10(std(Output_temp)^2/ std(Output_white - Output_temp)^2)
    %% alpha-stable distribution noise
   % BG=unifrnd(-3^0.5, 3^0.5, Length,1);
      BG=alpha_stable_noise(2,0.1,0,0,Length);

 Output  =  Output_white +BG ;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % LMP_out = LMP(Input_color_sequence,Output,Oweight,weight,mu_SA,Tap,1,Length,1);
 %    LMP_Mis(n,:) = LMP_out.MisWe;
     
  %    LMS_out = LMP(Input_color_sequence,Output,Oweight,weight,mu_LMS,Tap,1,Length,2);
  %   LMS_Mis(n,:) = LMS_out.MisWe; 
     
   LMS_SA_out = LMS_SA(Input_color_sequence,Output,Oweight,weight,mu_RMNA,Tap,1,Length,RMNA_a);
     LMS_SA_Mis(n,:) = LMS_SA_out.MisWe; 
 
      GMCC_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu_GMCC,0.00000001,Tap,1,HL,1,0,a,b,ERR,TT, BG);
       GMCC_Mis(n,:) = GMCC_out.MisWe;
     
         SAPA_out = SAPA(Input_color_sequence,Output,Oweight,weight,mu_SAPA,0.00000001,Tap,K,HL,a_sapa,b_sapa);
       SAPA_Mis(n,:) = SAPA_out.MisWe;
       
      SSM_AAPGMC_out = SSM_AAPGMC(Input_color_sequence,Output,Oweight,weight,mu_SSM_AAPGMC,0.00000001,Tap,K,HL,a_SSM_AAPGMC,b_SSM_AAPGMC,ax);
       SSM_AAPGMC_Mis(n,:) = SSM_AAPGMC_out.MisWe;
       
       
       
       
       
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    [ a1(mixed factor)   a2(mixed factor)   a(shape factor)    b(kernel factor)     ]        
       
      APA_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu_APA,0.00000001,Tap,K,HL,1,0,2,0,ERR,TT, BG);
       APA_Mis(n,:) = APA_out.MisWe;
       
        APLMCC_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu_APLMCC,0.00000001,Tap,K,HL,1,0,a,b,ERR,TT, BG);
       APLMCC_Mis(n,:) = APLMCC_out.MisWe;
       
        GMNMCC_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu_GMNMCC,0.00000001,Tap,1,HL,a1,a2,a,b,ERR,TT, BG);
       GMNMCC_Mis(n,:) = GMNMCC_out.MisWe;
     
      APGMNMCC_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu_APGMNMCC,0.00000001,Tap,K,HL,a1,a2,a,b,ERR,TT, BG);
       APGMNMCC_Mis(n,:) = APGMNMCC_out.MisWe;
   
   
end

  RMNA_Mis_mean=mean( LMS_SA_Mis);
  GMCC_Mis_mean=mean( GMCC_Mis);
  APA_Mis_mean=mean(APA_Mis);
  APLMCC_Mis_mean=mean(APLMCC_Mis);
   SAPA_Mis_mean=mean(SAPA_Mis);
      SSM_AAPGMC_Mis_mean=mean(SSM_AAPGMC_Mis);
  GMNMCC_Mis_mean=mean( GMNMCC_Mis);
  APGMNMCC_Mis_mean=mean(APGMNMCC_Mis);

    


  
figure
% plot(SA_Mis_mean,'k-.','LineWidth',2);
   plot( RMNA_Mis_mean,'b-.','LineWidth',2);
hold on
% plot(LMS_Mis_mean,'k','LineWidth',2);

    plot(GMCC_Mis_mean,'b','LineWidth',2);
   plot(APA_Mis_mean,'c-.','LineWidth',2);
 plot(APLMCC_Mis_mean,'c','LineWidth',2);
  plot(SAPA_Mis_mean,'k-.','LineWidth',2);
    plot(SSM_AAPGMC_Mis_mean,'k','LineWidth',2);
  plot(GMNMCC_Mis_mean,'r-.','LineWidth',2);
  plot(APGMNMCC_Mis_mean,'r','LineWidth',2);
% li=legend('SA','LMS','RMNA','GMCC','GMNMCC');
li=legend('RMNA','GMCC','APA','APLMCC','SAPA','SSM-AAPGMC','GMNMCC','AP-GMNMCC');
set(li,'Fontsize',8);
xlabel('iteration');
ylabel('WEP');
%save('fig1000','SA_Mis_mean','LMS_Mis_mean','RMNA_Mis_mean','GMCC_Mis_mean','APA_Mis_mean','APLMCC_Mis_mean','GMNMCC_Mis_mean','APGMNMCC_Mis_mean');
t2 = cputime;
exetime = t2 - t1

 