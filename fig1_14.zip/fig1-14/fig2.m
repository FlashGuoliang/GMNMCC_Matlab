clear all
close all
clc
t1 = cputime;
N   =100;                   %run times
TT=100;                     %mean coefficient
Tap = 10;                   %channel length
K   = 1;                    %projection
Length = 100000;            %iteration
HL=100000;                  %the moment of a mutation
%%%%%%%%%%%%% 
MU=[0.001:0.001:0.015];               % step size


m1=length(MU);                        %number of steps
  E11=zeros(1,m1);                    %initialize
  E00=zeros(1,m1);                    %initialize
%%%%% GMNMCC
a1=0.3;               % the first mixed factor
a2=0.1;               % the second mixed factor
a=2;                  % shape factor
b=0.01;               %  kernel factor
%% Input - Output pairs
Input_white_sequence  =  randn(Length,1);                %inputs
Input_color_sequence  = Input_white_sequence;
%Input_color_sequence  =  filter(1,[1 -0.7],Input_white_sequence);  %color
%inputs


%%   The weights of the system
%Oweight1               =  zeros(Tap,1);
%for n = 1 : round(0.9*Tap)                 %%  ����1*Tap�������
%    Oweight1(unidrnd(Tap)) = randn;
%end
Oweight1               =  [0.11 0.21 0.31 0.41 0.51 0.51 0.41 0.31 0.21 0.11]';   
Oweight2               = -Oweight1;
Oweight                = [Oweight1 Oweight2];

%% Output of the system
Output_temp1           =  filter(Oweight1,1,Input_color_sequence(1:HL));
Output_temp2           =  filter(Oweight2,1,Input_color_sequence((HL+1):end));
Output_temp            =  [Output_temp1 ; Output_temp2];
ERR=zeros(Length,1);           %initialize
A=zeros(Length,1)';            %initialize

%% runs
for m=1:length(MU)
    mu=MU(m);                   % Choose a step size          
for n = 1:N
    if ~mod(n,N/10), fprintf('.'); end                   % progress bar
    weight = zeros(Tap,1);                               % initialize of the weight
    Output_white =Output_temp;                           % output
   %  Output_white = AWGNgen(Output_temp,30);
  %  Output_white = awgn(Output_temp,30,'measured');     %Add white Gaussian noise to the signal
%     10*log10(std(Output_temp)^2/ std(Output_white - Output_temp)^2)
    %% noise
    BG=unifrnd(-3^0.5, 3^0.5, Length,1);
     % BG=alpha_stable_noise(1.5,0.1,0,0,Length);             % alpha-stable distribution noise
  %  Output  =  Output_white + BG;                            % output with noise
%     10*log10(std(Output_temp)^2/ std(BG)^2)
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
 Output  =  Output_white +BG ;                                % output with noise
 

     %% K=1,the funtion of the GMNMCC
      APGMNMCC_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu,0.00000001,Tap,K,HL,a1,a2,a,b,ERR,TT, BG);

       APGMNMCC_Mis(n,:) = APGMNMCC_out.MisER;               % reading data
    SS1_Mis(n,:) = APGMNMCC_out.MisERS1;                     % reading data          
    SS2_Mis(n,:) = APGMNMCC_out.MisERS2;                     % reading data
   
end

     APGMNMCC_Mis_mean=mean(APGMNMCC_Mis);                   % mean value
      SS1_Mis_mean=mean(SS1_Mis);                            % mean value
       SS2_Mis_mean=mean(SS2_Mis);                           % mean value
  APGMNMCC1=(APGMNMCC_Mis_mean./(TT));
  SS1=(SS1_Mis_mean./(TT));
  SS2=(SS2_Mis_mean./(TT));
  S=mu*Tap*K*SS1./(2*SS2);                                 
  E11(m) =mean(APGMNMCC1(Length-100: Length));              % mean value of MSE (simulation)
  E00(m) =S(Length );                                       % mean value of MSE (theory)
end
 %% draw
figure
 plot(MU, E11,'k-*','LineWidth',1);                       
hold on
 plot(MU,  E00,'r-^','LineWidth',1);
%plot(APGMNMCC,'k-.','LineWidth',1);
 %plot(S,'r','LineWidth',1);
li=legend('simulation','theory');
set(li,'Fontsize',8);
xlabel('iteration');
ylabel('EMSE');
%save('fig30','LMP_Mis_mean','ZALMP_Mis_mean','GCIMLMP_Mis_mean');
%save('fig400','LMP_Mis_mean','LMS_SA_Mis_mean','APSA_Mis_mean','APGMCC_Mis_mean','AP_LMS_SA_Mis_mean','APGMCLMS_SA_Mis_mean','S_APGMCLMS_SA_Mis_mean');

t2 = cputime;
exetime = t2 - t1
%E11 =APGMNMCC(Length )
 %E00 =S(Length )
 