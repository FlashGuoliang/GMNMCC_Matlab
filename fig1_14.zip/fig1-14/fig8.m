clear all
close all
clc
t1 = cputime;
N   =100;
TT=100;
Tap = 10;  
K   = 1;
Length = 8000;
HL=8000;
%%%%%%%%%%%%% APRMNA
mu=0.001;
MU=[ 0 0.1 0.5 0.8 1];              

%MU=0.01;
m1=length(MU);
  E11=zeros(1,m1);
  E00=zeros(1,m1);
     fno=zeros(1,m1);

a1=1;               % the first mixed factor
%a2=1;               % the second mixed factor
a=2;             % shape factor
b=0.001;          %  kernel factor
%% Input - Output pairs
Input_white_sequence  =  randn(Length,1);
Input_color_sequence  = Input_white_sequence;
%Input_color_sequence  =  filter(1,[1 -0.7],Input_white_sequence);

Oweight1               =  zeros(Tap,1);
for n = 1 : round(Tap)                 %%  ����1*Tap�������
    Oweight1(unidrnd(Tap)) = randn;
end
%Oweight1               =  [0.11 0.21 0.31 0.41 0.51 0.51 0.41 0.31 0.21 0.11]';
Oweight2               = -Oweight1;
Oweight                = [Oweight1 Oweight2];

Output_temp1           =  filter(Oweight1,1,Input_color_sequence(1:HL));
Output_temp2           =  filter(Oweight2,1,Input_color_sequence((HL+1):end));
Output_temp            =  [Output_temp1 ; Output_temp2];
ERR=zeros(Length,1);
A=zeros(Length,1)';
%SE=zeros(Length,1);
%% runs
for m=1:length(MU)
    a2=MU(m);
   % fno(m)=4*no^2/12;
for n = 1:N
    if ~mod(n,N/10), fprintf('.'); end               %%       �ж��Ƿ�20/10����
    weight = zeros(Tap,1);
    Output_white =Output_temp;
   %  Output_white = AWGNgen(Output_temp,30);
  %  Output_white = awgn(Output_temp,30,'measured');   %%����ɫ��˹�������ӵ��ź���
%     10*log10(std(Output_temp)^2/ std(Output_white - Output_temp)^2)
    %% alpha-stable distribution noise
   % BG=unifrnd(-3^0.5, 3^0.5, Length,1);
      BG=alpha_stable_noise(2,0.1,0,0,Length);
  %  Output  =  Output_white + BG;  %���зǸ�˹���������
%     10*log10(std(Output_temp)^2/ std(BG)^2)
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
 Output  =  Output_white +BG ;
 

     
      APGMNMCC_out = APGMNMCC(Input_color_sequence,Output,Oweight,weight,mu,0.00000001,Tap,K,HL,a1,a2,a,b,ERR,TT, BG);

       APGMNMCC_Mis(n,:) = APGMNMCC_out.MisWe;
   
   
end

     APGMNMCC_Mis_mean(m,:)=mean(APGMNMCC_Mis);

end
  
figure
 plot(APGMNMCC_Mis_mean(1,:),'k-.','LineWidth',2);
hold on
 plot(APGMNMCC_Mis_mean(2,:),'b-.','LineWidth',2);
  plot(APGMNMCC_Mis_mean(3,:),'c-.','LineWidth',2);
   plot(APGMNMCC_Mis_mean(4,:),'r-.','LineWidth',2);
 plot(APGMNMCC_Mis_mean(5,:),'r','LineWidth',2);
li=legend('GMNMCC','GMNMCC','GMNMCC','GMNMCC','GMNMCC');
set(li,'Fontsize',8);
xlabel('iteration');
ylabel('EMSE');
%save('fig30','LMP_Mis_mean','ZALMP_Mis_mean','GCIMLMP_Mis_mean');
%save('fig400','LMP_Mis_mean','LMS_SA_Mis_mean','APSA_Mis_mean','APGMCC_Mis_mean','AP_LMS_SA_Mis_mean','APGMCLMS_SA_Mis_mean','S_APGMCLMS_SA_Mis_mean');
%save('fig800','APGMNMCC_Mis_mean');
t2 = cputime;
exetime = t2 - t1
%E11 =APGMNMCC(Length )
 %E00 =S(Length )
 