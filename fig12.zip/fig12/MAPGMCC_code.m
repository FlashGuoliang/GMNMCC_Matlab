function out = MAPGMCC_code(input,output,weight,rate,epsilon,r,K,alpha,BE)
    err = output - input'*weight;
    B=zeros(1,K);
    for k=1:K
        B(k)=exp(-1*r*abs(err(k))^alpha)*(abs(err(k)))^(alpha-1);
    %  B(k)=exp(-1*r*abs(err(1))^alpha)*(abs(err(1)))^(alpha-1);
%B(k)=(1-r*abs(err(k))^alpha)*(abs(err(k)))^(alpha-1);
    end
   %BC=B';    
    %B=diag(B);
  
   % BE=[BC BE(:,1:K-1)];
    BE=diag(B);
 % BE=B';
   input_s = input*sign(err);
    %weight=weight+rate*input*(BE.*sign(err))./(sqrt( norm(input*(BE.*sign(err)))^2+ epsilon  )); 
      weight=weight+rate*input*(BE*sign(err))./(sqrt( norm(input*(BE*sign(err)))^2+ epsilon  )); 
  
    out.weight = weight;
   % out.BE = BE;
end