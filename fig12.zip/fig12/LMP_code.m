function out = LMP_code(input,output,weight,rate,Tap,p)
    err = output - input'*weight; 
   input_s=sign(err(1))*input;
    weight  = weight + rate*input_s*abs(err(1))^(p-1);
    out.weight = weight;
  
end