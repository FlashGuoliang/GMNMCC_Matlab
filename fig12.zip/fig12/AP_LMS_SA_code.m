function out = AP_LMS_SA_code(input,output,weight,rate,epsilon,a)
    err = output - input'*weight;
    input_s = input*sign(err);
    %weight  = weight + rate*input*(a*sign(err)+(1-a)*err)./(sqrt( norm(a*input_s)^2+ norm((1-a)*input*err)^2+ epsilon  ));       %norm���ص��Ǿ���Ķ�����
   weight  = weight + rate*input*(a*sign(err)+2*(1-a)*err)./(sqrt( norm(a*input_s+(1-a)*input*err)^2+ epsilon  ));  
    out.weight = weight;
end