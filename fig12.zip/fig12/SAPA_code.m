function out = SAPA_code(input,output,weight,rate,epsilon,a_sapa,b_sapa)
    err = output - input'*weight;
    input_s = input*sign(err);
    weight  = weight + rate*input*((2*b_sapa*abs(err).*exp(-a_sapa*err.^2))./((b_sapa+exp(-a_sapa*err.^2)).^2).*sign(err))/(sqrt( norm(input_s)^2 + epsilon  ));       %norm���ص��Ǿ���Ķ�����
    out.weight = weight;
end