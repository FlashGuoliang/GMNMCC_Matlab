function out = APSA_code(input,output,weight,rate,epsilon)
    err = output - input'*weight;
    input_s = input*sign(err);
    weight  = weight + rate*input_s./(sqrt( norm(input_s)^2 + epsilon  ));       %norm���ص��Ǿ���Ķ�����
    out.weight = weight;
end