function out = SSM_AAPGMC_code(input,output,weight,rate,epsilon,a_SSM_AAPGMC,b_SSM_AAPGMC,ax)
    err = output - input'*weight;
    input_s = input*sign(err);
%     if err(1)^2>ax^2
%         rate=1-abs(ax/err(1));
%     else
%         rate=0;
%     end
    weight  = weight + rate*input*(input'*input+input'*input)^(-1)*(exp(-b_SSM_AAPGMC*abs(err).^(4*a_SSM_AAPGMC)).*abs(err).^(2*a_SSM_AAPGMC-2).*err);       %norm���ص��Ǿ���Ķ�����
    out.weight = weight;
end