function out = LMS_SA(Input,Output,Oweight,weight,rate,Tap,K,HL,a)
L = length(Input);
for n = Tap+K+1:L
    Input_temp = [Input(n:-1:n-Tap+1)];
   
        Input_temp = [Input_temp ];
  
    Output_tmep = Output(n:-1:n-K+1);
  
   if n<= HL
        Oweight_temp = Oweight(:,1);
    else
       Oweight_temp = Oweight(:,2);
      %  if n == HL+1
        %    weight = zeros(Tap,1);
        %end
    end
 
    OU = LMS_SA_code(Input_temp,Output_tmep,weight,rate,Tap,a);
    weight =  OU.weight;
    
    out.MisWe(n) = 10*log10(norm(weight - Oweight_temp)); % the normalized misalignment
end
out.final_weight = weight;
end