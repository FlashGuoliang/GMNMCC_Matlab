function out = APGMCLMS_SA_code(input,output,weight,rate,epsilon,r,K,alpha,a)

    err = output - input'*weight;
    err1=a*abs(err)+(1-a)*err.^2;
    B=zeros(1,K);
    for k=1:K
        B(k)=exp(-1*r*abs(err1(k))^alpha)*(abs(err1(k)))^(alpha-1);
    end
    B=diag(B);

   % weight=weight+rate*input*B*(a*sign(err)+2*(1-a)*err)./(sqrt( norm(input*B*(a*sign(err)+2*(1-a)*err))^2+ epsilon  )); 
  weight=weight+rate*input*B*(a*sign(err)+2*(1-a)*err)./(sqrt( norm(input*B*(a*sign(err)+2*(1-a)*err))^2+ epsilon  )); 
    out.weight = weight;
end